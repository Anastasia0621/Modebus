# Modbus_RTU
 stm32f103c8t6基于modbus协议和使用串口读取温湿度
